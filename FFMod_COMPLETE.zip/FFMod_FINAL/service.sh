#!/system/bin/sh
MODDIR=${0%/*}
log_print "Free Fire Mod: Service active"

# Monitor and clean anticheat telemetry in realtime
while true; do
  # Kill anticheat reporting processes
  pkill -f "anticheat"
  pkill -f "easy_anti"

  # Clear logcat traces
  logcat -c 2>/dev/null

  sleep 30
done &
