#!/system/bin/sh
MODDIR=${0%/*}
log_print "Free Fire Mod: Initializing anti-ban layer"

# Spoof device properties before anticheat checks
resetprop ro.build.fingerprint "OnePlus/OnePlus7Pro/OnePlus7Pro:11/RQ3A.200705.001/2008232022:user/release-keys"
resetprop ro.build.version.security_patch "2024-01-01"
resetprop ro.debuggable 0
resetprop ro.secure 1

# Inject native library
export LD_PRELOAD="$MODDIR/lib64/libfiremod.so"
