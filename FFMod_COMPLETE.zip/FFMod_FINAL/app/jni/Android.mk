LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := firemod
LOCAL_SRC_FILES := cheats.cpp
LOCAL_CFLAGS := -fvisibility=hidden -O3
LOCAL_LDLIBS := -llog -ldl
include $(BUILD_SHARED_LIBRARY)
