package com.firemod;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.FrameLayout;

public class CheatMenu {

    static {
        System.loadLibrary("firemod");
    }

    private static Context appContext;
    private static FrameLayout menuOverlay;
    private static LinearLayout menuPanel;
    private static boolean menuVisible = false;
    private static WindowManager windowManager;
    private static WindowManager.LayoutParams layoutParams;

    // Native functions
    public native void toggleSpinbot();
    public native void toggleLagSwitch();
    public native void toggleWallHack();
    public native void toggleDamageMult();
    public native void toggleSpeedHack();
    public native void toggleNoRecoil();
    public native void toggleRapidFire();
    public native void toggleInvisibility();
    public native void toggleInstantReload();
    public native void togglePlayerGlow();
    public native void setSpinbotSpeed(float speed);
    public native void setDamageMultiplier(int mult);
    public native void setSpeedMultiplier(float mult);

    public static void initialize(Context context) {
        appContext = context;
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        // Gesture detection: 3-finger tap to show menu
        setupGestureListener();
    }

    private static void setupGestureListener() {
        // In real implementation: use GestureDetector for 3-finger tap
        // For now, menu can be toggled via broadcast or notification tap
    }

    public static void showMenu() {
        if (menuVisible) return;

        // Create overlay frame
        menuOverlay = new FrameLayout(appContext);
        menuOverlay.setLayoutParams(new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // Main menu panel
        menuPanel = new LinearLayout(appContext);
        menuPanel.setOrientation(LinearLayout.VERTICAL);
        menuPanel.setBackgroundColor(Color.parseColor("#1a1a1a"));
        menuPanel.setPadding(20, 20, 20, 20);

        FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(
            400, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.LEFT
        );
        panelParams.setMargins(10, 50, 0, 0);
        menuPanel.setLayoutParams(panelParams);

        // Title
        TextView title = new TextView(appContext);
        title.setText("FF CHEAT MENU v1.0");
        title.setTextColor(Color.parseColor("#ff6600"));
        title.setTextSize(16);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        menuPanel.addView(title);

        // Separator
        View sep1 = new View(appContext);
        sep1.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 2
        ));
        sep1.setBackgroundColor(Color.parseColor("#ff6600"));
        menuPanel.addView(sep1);

        // ========== 1. SPINBOT ==========
        addToggleButton("1. SPINBOT", new Runnable() {
            @Override public void run() { toggleSpinbot(); }
        });
        addSlider("Spinbot Speed", 1.0f, 360.0f, 90.0f, new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) setSpinbotSpeed(progress * 1.0f);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // ========== 2. LAG SWITCH ==========
        addToggleButton("2. LAG SWITCH", new Runnable() {
            @Override public void run() { toggleLagSwitch(); }
        });

        // ========== 3. WALL HACK ==========
        addToggleButton("3. WALL HACK", new Runnable() {
            @Override public void run() { toggleWallHack(); }
        });

        // ========== 4. DAMAGE MULTIPLIER ==========
        addToggleButton("4. DAMAGE MULT", new Runnable() {
            @Override public void run() { toggleDamageMult(); }
        });
        addSlider("Damage Mult (x)", 1, 5, 2, new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) setDamageMultiplier(progress + 1);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // ========== 5. SPEED HACK ==========
        addToggleButton("5. SPEED HACK", new Runnable() {
            @Override public void run() { toggleSpeedHack(); }
        });
        addSlider("Speed Mult (x)", 1.0f, 3.0f, 1.5f, new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) setSpeedMultiplier(1.0f + (progress / 100.0f));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // ========== 6. NO RECOIL ==========
        addToggleButton("6. NO RECOIL", new Runnable() {
            @Override public void run() { toggleNoRecoil(); }
        });

        // ========== 7. RAPID FIRE ==========
        addToggleButton("7. RAPID FIRE", new Runnable() {
            @Override public void run() { toggleRapidFire(); }
        });

        // ========== 8. INVISIBILITY ==========
        addToggleButton("8. INVISIBILITY", new Runnable() {
            @Override public void run() { toggleInvisibility(); }
        });

        // ========== 9. INSTANT RELOAD ==========
        addToggleButton("9. INSTANT RELOAD", new Runnable() {
            @Override public void run() { toggleInstantReload(); }
        });

        // ========== 10. PLAYER GLOW ==========
        addToggleButton("10. PLAYER GLOW", new Runnable() {
            @Override public void run() { togglePlayerGlow(); }
        });

        // Close button
        Button closeBtn = new Button(appContext);
        closeBtn.setText("CLOSE MENU");
        closeBtn.setBackgroundColor(Color.parseColor("#ff6600"));
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hideMenu(); }
        });
        menuPanel.addView(closeBtn);

        // Add panel to overlay
        menuOverlay.addView(menuPanel);

        // Add to window
        layoutParams = new WindowManager.LayoutParams();
        layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        layoutParams.format = android.graphics.PixelFormat.TRANSLUCENT;
        layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                           WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.x = 0;
        layoutParams.y = 0;

        windowManager.addView(menuOverlay, layoutParams);
        menuVisible = true;
    }

    private static void addToggleButton(String label, final Runnable action) {
        Button btn = new Button(appContext);
        btn.setText(label);
        btn.setBackgroundColor(Color.parseColor("#2a2a2a"));
        btn.setTextColor(Color.parseColor("#ff6600"));
        btn.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            80
        ));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                action.run();
            }
        });

        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) btn.getLayoutParams();
        lp.setMargins(0, 8, 0, 8);
        menuPanel.addView(btn, lp);
    }

    private static void addSlider(String label, float min, float max, float initial,
                                 SeekBar.OnSeekBarChangeListener listener) {
        // Label
        TextView labelView = new TextView(appContext);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#cccccc"));
        labelView.setTextSize(12);
        menuPanel.addView(labelView);

        // Slider
        SeekBar slider = new SeekBar(appContext);
        slider.setMax((int)(max - min));
        slider.setProgress((int)(initial - min));
        slider.setOnSeekBarChangeListener(listener);
        menuPanel.addView(slider);
    }

    public static void hideMenu() {
        if (menuVisible && menuOverlay != null) {
            windowManager.removeView(menuOverlay);
            menuVisible = false;
            menuOverlay = null;
            menuPanel = null;
        }
    }
}
